"use client";

import { useState } from "react";
import { AiOutlineEye, AiOutlineEyeInvisible } from "react-icons/ai";
import { useForm } from "react-hook-form";
 
type FormValues = {
  email: string;
  password: string;
};

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<FormValues>({
    mode: "onChange",
  });

  const onSubmit = async (data: FormValues) => {
    setLoading(true);
    try {
      const response = await fetch("http://10.11.106.31:5001/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (!response.ok) {
        alert(result.message || "Login failed");
        return;
      }

      alert("Login successful ✅");
      console.log("User logged in:", result);

      reset();
    } catch (error) {
      console.error("Server error:", error);
      alert("Server connection error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        backgroundColor: "#F2EDE9",
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: "20px",
      }}
    >
      <form
        onSubmit={handleSubmit(onSubmit)}
        style={{
          backgroundColor: "#fff",
          padding: "40px",
          borderRadius: "12px",
          width: "100%",
          maxWidth: "400px",
          boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
          display: "flex",
          flexDirection: "column",
          gap: "20px",
        }}
      >
        <h2 style={{ textAlign: "center", marginBottom: "10px" }}>Login</h2>

        {/* Email */}
        <div style={{ display: "flex", flexDirection: "column" }}>
          <label>Email</label>
          <input
            type="email"
            placeholder="Enter your email"
            {...register("email", { required: "Email is required" })}
            style={{
              padding: "12px",
              borderRadius: "8px",
              border: errors.email ? "2px solid red" : "1px solid #ccc",
              fontSize: "16px",
            }}
          />
          {errors.email && (
            <span style={{ color: "red", fontSize: "14px", marginTop: "4px" }}>
              {errors.email.message}
            </span>
          )}
        </div>

        {/* Password */}
        <div style={{ position: "relative", display: "flex", flexDirection: "column" }}>
          <label>Password</label>
          <input
            type={showPassword ? "text" : "password"}
            placeholder="Enter your password"
            {...register("password", {
              required: "Password is required",
              minLength: { value: 8, message: "Password must be at least 8 characters" },
            })}
            style={{
              padding: "12px",
              borderRadius: "8px",
              border: errors.password ? "2px solid red" : "1px solid #ccc",
              fontSize: "16px",
            }}
          />
          <span
            onClick={() => setShowPassword(!showPassword)}
            style={{
              position: "absolute",
              right: "12px",
              top: "38px",
              cursor: "pointer",
              color: "#555",
            }}
          >
            {showPassword ? <AiOutlineEye /> : <AiOutlineEyeInvisible />}
          </span>
          {errors.password && (
            <span style={{ color: "red", fontSize: "14px", marginTop: "4px" }}>
              {errors.password.message}
            </span>
          )}
        </div>

        {/* Submit button */}
        <button
          type="submit"
          disabled={loading}
          style={{
            padding: "14px",
            borderRadius: "9999px",
            border: "2px solid #8F5A89",
            backgroundColor: "#76356E",
            color: "#fff",
            fontWeight: 500,
            fontSize: "16px",
            cursor: "pointer",
            width: "100%",
          }}
        >
          {loading ? "Submitting..." : "Login"}
        </button>
      </form>
    </div>
  );
}