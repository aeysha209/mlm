export interface RegistrationRequest {
  email: string;
  password: string;
  nickname: string;
  name: string;
  referralCode?: string;
}